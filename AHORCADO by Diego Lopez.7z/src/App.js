import React, { Component } from 'react';
import Ahorcado from "./Componentes/Ahorcado";

class App extends Component {
  render() {
    return (
        <Ahorcado />
    );
  }
}

export default App;
